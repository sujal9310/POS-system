<?php
namespace ReceiptPrintHq\EscposTools\Parser\Command;

interface TextContainer
{
    public function getText();
}
