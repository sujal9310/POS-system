<?php
require("load_html.php");
$call = new loads;
$call->read_head();
?>

				<!--footer-->
		<div class="footer">
		   <p>&copy; 2018 Gigmoz. All Rights Reserved</p>
	   </div>
        <!--//footer-->
<?php
$call->read_foot();
?>